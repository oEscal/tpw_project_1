from django.contrib import admin
from page.models import *


admin.site.register(Stadium)
admin.site.register(Team)
admin.site.register(Game)
admin.site.register(GameStatus)
admin.site.register(Position)
admin.site.register(Player)
admin.site.register(KindEvent)
admin.site.register(Event)
admin.site.register(PlayerPlayGame)
